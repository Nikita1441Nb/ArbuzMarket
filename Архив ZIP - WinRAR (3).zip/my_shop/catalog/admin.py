from django.contrib import admin
from .models import Category, Product, ProductImage

# Позволяет добавлять картинки прямо на странице товара
class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)} # Автоматически делает slug из названия

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'old_price', 'stock', 'is_active'] 
    search_fields = ['name', 'description']
    list_filter = ['category', 'is_active']
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ProductImageInline] # Добавляем блок с картинками